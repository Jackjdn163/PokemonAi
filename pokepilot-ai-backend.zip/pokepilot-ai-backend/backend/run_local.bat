python -m venv .venv
call .venv\Scripts\activate
pip install -r requirements.txt
ollama pull llama3.1
python ingest.py
uvicorn app:app --reload
