#!/bin/bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
ollama pull llama3.1
python ingest.py
uvicorn app:app --reload
