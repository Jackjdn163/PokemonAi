import chromadb
import ollama
from chromadb.utils.embedding_functions import SentenceTransformerEmbeddingFunction


DB_PATH = "./data/chroma"


embedding_function = SentenceTransformerEmbeddingFunction(
    model_name="all-MiniLM-L6-v2"
)

client = chromadb.PersistentClient(path=DB_PATH)

collection = client.get_or_create_collection(
    name="pokemon_knowledge",
    embedding_function=embedding_function,
)


def search_knowledge(question: str, results: int = 8):
    search_results = collection.query(
        query_texts=[question],
        n_results=results,
    )

    documents = search_results["documents"][0]
    metadatas = search_results["metadatas"][0]

    chunks = []

    for doc, meta in zip(documents, metadatas):
        chunks.append({
            "title": meta.get("title", "Unknown"),
            "source": meta.get("source", "Unknown"),
            "text": doc,
        })

    return chunks


def answer_question(question: str) -> dict:
    chunks = search_knowledge(question)

    context = "\n\n".join(
        [
            f"Source: {chunk['source']}\nTitle: {chunk['title']}\nInfo: {chunk['text']}"
            for chunk in chunks
        ]
    )

    prompt = f"""
You are Poképilot AI, a helpful Pokémon assistant for casual single-player Pokémon players.

Answer the user's question using ONLY the provided context.
If the answer is not in the context, say that you do not have enough information.
Be clear, useful, and beginner-friendly.

User question:
{question}

Context:
{context}

Answer:
"""

    response = ollama.chat(
        model="llama3.1",
        messages=[{"role": "user", "content": prompt}],
    )

    return {
        "answer": response["message"]["content"],
        "sources": [{"title": chunk["title"], "source": chunk["source"]} for chunk in chunks],
    }
