# Poképilot AI Backend

A Pokémon question-answering AI backend using FastAPI, ChromaDB, PokéAPI data, and Ollama.

## Easiest setup

### Mac/Linux/Chromebook terminal

```bash
cd backend
chmod +x run_local.sh
./run_local.sh
```

### Windows

```bat
cd backend
run_local.bat
```

The backend will run at:

```txt
http://127.0.0.1:8000
```

Ask endpoint:

```txt
POST http://127.0.0.1:8000/ask
```

Example body:

```json
{
  "question": "How do I evolve Riolu?"
}
```

## Manual setup

```bash
cd backend
pip install -r requirements.txt
ollama pull llama3.1
python ingest.py
uvicorn app:app --reload
```
